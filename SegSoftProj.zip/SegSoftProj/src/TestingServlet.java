import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Account.AccountInterface;
import Authenticator.*;
import Exceptions.AuthenticationError;
import Exceptions.IncompleteParametersException;
import Exceptions.LockedException;
import Exceptions.LoggedInException;
import Exceptions.NonExistentUserException;
import Exceptions.PasswordException;
import Exceptions.UserExistsException;

public class TestingServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private AuthenticatorInterface auth;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		auth = new Authenticator();
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<HTML>");
		out.println("<HEAD>");
		out.println("<H1>Manage Users</H1>");
		out.println("</HEAD>");
		out.println("<BODY>");
		showCreate(out);
		showDelete(out);
		showGet(out);
		showChangePwd(out);
		showLogin(out);
		out.println(
				"<button type=\"button\"  onclick = \"document.getElementById('form1').style.display = 'block'\">Add New Account</button>");
		out.println(
				"<button type=\"button\"  onclick = \"document.getElementById('form2').style.display = 'block'\">Delete Account</button>");
		out.println(
				"<button type=\"button\"  onclick = \"document.getElementById('form3').style.display = 'block'\">Get Existing Account</button>");
		out.println(
				"<button type=\"button\"  onclick = \"document.getElementById('form4').style.display = 'block'\">Change Password</button>");
		out.println(
				"<button type=\"button\"  onclick = \"document.getElementById('form5').style.display = 'block'\">Login</button><br><br>");
		showLogout(out);
		showmyAppButton(out);
		out.println("</BODY>");
		out.println("</HTML>");
		createAccountMethod(request, auth, out);
		deleteAccountMethod(request, auth, out);
		getAccountMethod(request, auth, out);
		changePwdMethod(request, auth, out);
		loginMethod(request, response, auth, out);
		logoutMethod(request, auth, out);
		gotoMyAppMethod(request, response, auth, out);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	private void showCreate(PrintWriter out) {
		out.println("<form action = '/SegSoftProj/test' method=\"post\" id=\"form1\" style=\"display:none\">");
		out.println("<label for=\"user\">Username:</label>");
		out.println("<input type=\"text\" id=\"username\" name=\"username\"><br><br>");
		out.println("<label for=\"pwd\">Password:</label>");
		out.println("<input type=\"password\" id=\"password\" name=\"password\"><br><br>");
		out.println("<label for=\"pwd2\">Confirm Password:</label>");
		out.println("<input type=\"password\" id=\"password2\" name=\"password2\">");
		out.println("<button type=\"submit\" form=\"form1\" value=\"Submit\">Create</button>");
		out.println("</form>");
	}

	private void createAccountMethod(HttpServletRequest request, AuthenticatorInterface auth, PrintWriter out) {
		String usernameCreate = request.getParameter("username");
		String pwdCreate = request.getParameter("password");
		String confirmPassword = request.getParameter("password2");
		boolean accountCreated = true;
		if (usernameCreate != null && pwdCreate != null) {
			try {
				HttpSession session = request.getSession(false);
				if (session != null && session.getAttribute("Name").equals("root")) {
					auth.create_account(usernameCreate, pwdCreate, confirmPassword);
					if (accountCreated) {
						out.println("<script type=\"text/javascript\">");
						out.println("alert('Account Created');");
						out.println("</script>");
					}
				} else {
					out.println("<script type=\"text/javascript\">");
					out.println("alert('Failed Creating - Not root user');");
					out.println("</script>");
				}
			} catch (PasswordException e) {
				accountCreated = false;
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Passwords do not match');");
				out.println("</script>");
			} catch (UserExistsException e1) {
				accountCreated = false;
				out.println("<script type=\"text/javascript\">");
				out.println("alert('User already exists');");
				out.println("</script>");
			} catch (IncompleteParametersException e2) {
				accountCreated = false;
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Please fill all parameters before submitting');");
				out.println("</script>");
			}
		}
	}

	private void showDelete(PrintWriter out) {
		out.println("<form action = '/SegSoftProj/test' method=\"post\" id=\"form2\" style=\"display:none\">");
		out.println("<label for=\"user\">Username:</label>");
		out.println("<input type=\"text\" id=\"usernameDelete\" name=\"usernameDelete\"><br><br>");
		out.println("<button type=\"submit\" form=\"form1\" value=\"Submit\">Delete</button>");
		out.println("</form>");
	}

	private void deleteAccountMethod(HttpServletRequest request, AuthenticatorInterface auth, PrintWriter out) {
		String username = request.getParameter("usernameDelete");
		boolean accountDelete = true;
		if (username != null) {
			try {
				HttpSession session = request.getSession(false);
				if (session != null && session.getAttribute("Name").equals("root")) {
					auth.delete_account(username);
					if (accountDelete) {
						out.println("<script type=\"text/javascript\">");
						out.println("alert('Account successfully deleted');");
						out.println("</script>");
					}
				} else {
					out.println("<script type=\"text/javascript\">");
					out.println("alert('Failed Deleting - Not root user');");
					out.println("</script>");
				}
			} catch (NonExistentUserException e) {
				accountDelete = false;
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Account does not exist');");
				out.println("</script>");
			} catch (LoggedInException e) {
				accountDelete = false;
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Account is still logged in');");
				out.println("</script>");
			} catch (IncompleteParametersException e) {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Please fill all parameters before submitting');");
				out.println("</script>");
				accountDelete = false;
			}
		}
	}

	private void showGet(PrintWriter out) {
		out.println("<form action = '/SegSoftProj/test' method=\"post\" id=\"form3\" style=\"display:none\">");
		out.println("<label for=\"user\">Username:</label>");
		out.println("<input type=\"text\" id=\"usernameGet\" name=\"usernameGet\"><br><br>");
		out.println("<button type=\"submit\" form=\"form3\" value=\"Submit\">Get</button>");
		out.println("</form>");
	}

	private void getAccountMethod(HttpServletRequest request, AuthenticatorInterface auth, PrintWriter out) {
		String username = request.getParameter("usernameGet");
		boolean getAccount = true;
		if (username != null) {
			try {
				HttpSession session = request.getSession(false);
				if (session != null) {
					AccountInterface acc = auth.get_account(username);
					if (getAccount) {
						if (!acc.isLocked()) {
							if (acc.isLogged_in())
								out.println("Account with username " + username + " is not locked and is logged in");
							else
								out.println(
										"Account with username " + username + " is not locked and is not logged in");
						} else
							out.println("Account with username " + username + " is locked");
					}
				}
				else {
					out.println("<script type=\"text/javascript\">");
					out.println("alert('Failed Request - not logged in');");
					out.println("</script>");
				}
			} catch (NonExistentUserException e) {
				getAccount = false;
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Account does not exist');");
				out.println("</script>");
			}
		}
	}

	private void showChangePwd(PrintWriter out) {
		out.println("<form action = '/SegSoftProj/test' method=\"post\" id=\"form4\" style=\"display:none\">");
		out.println("<label for=\"user\">Username:</label>");
		out.println("<input type=\"text\" id=\"usernameChange\" name=\"usernameChange\"><br><br>");
		out.println("<label for=\"user\">Old Password:</label>");
		out.println("<input type=\"password\" id=\"oldPwd\" name=\"oldPwd\"><br><br>");
		out.println("<label for=\"user\">New Password:</label>");
		out.println("<input type=\"password\" id=\"newPwd\" name=\"newPwd\"><br><br>");
		out.println("<button type=\"submit\" form=\"form4\" value=\"Submit\">Submit</button>");
		out.println("</form>");
	}

	private void changePwdMethod(HttpServletRequest request, AuthenticatorInterface auth, PrintWriter out) {
		String username = request.getParameter("usernameChange");
		String oldPwd = request.getParameter("oldPwd");
		String newPwd = request.getParameter("newPwd");
		boolean pwdChange = true;
		if (username != null && oldPwd != null && newPwd != null) {
			try {
				HttpSession session = request.getSession(false);
				if (session != null && (session.getAttribute("Name").equals(username) || session.getAttribute("Name").equals("root"))) {
					auth.change_pwd(username, oldPwd, newPwd);
					if (pwdChange) {
						out.println("<script type=\"text/javascript\">");
						out.println("alert('Password succesfully updated');");
						out.println("</script>");
					}
				} else {
					out.println("<script type=\"text/javascript\">");
					out.println("alert('Account not Logged in - Failed request');");
					out.println("</script>");
				}
			} catch (NonExistentUserException e) {
				pwdChange = false;
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Account does not exist');");
				out.println("</script>");
			} catch (PasswordException e) {
				pwdChange = false;
				out.println("<script type=\"text/javascript\">");
				out.println("alert('New password cannot be the same as old password');");
				out.println("</script>");
			}
		}
	}

	private void showLogin(PrintWriter out) {
		out.println("<form action = '/SegSoftProj/test' method=\"post\" id=\"form5\" style=\"display:none\">");
		out.println("<label for=\"user\">Username:</label>");
		out.println("<input type=\"text\" id=\"usernameLogin\" name=\"usernameLogin\"><br><br>");
		out.println("<label for=\"user\">Password:</label>");
		out.println("<input type=\"password\" id=\"pwdLogin\" name=\"pwdLogin\"><br><br>");
		out.println("<button type=\"submit\" form=\"form5\" value=\"Submit\">Submit</button>");
		out.println("</form>");
	}

	private void loginMethod(HttpServletRequest req, HttpServletResponse resp, AuthenticatorInterface auth,
			PrintWriter out) {
		boolean login = true;
		AccountInterface acc;
		try {
			acc = auth.login(req, resp);
			if (acc != null) {
				if (login) {
					out.println("<script type=\"text/javascript\">");
					out.println("alert('Account succesfully logged in');");
					out.println("</script>");
				}
			}
		} catch (NonExistentUserException e) {
			login = false;
			out.println("<script type=\"text/javascript\">");
			out.println("alert('Account does not exist');");
			out.println("</script>");
		} catch (LockedException e) {
			login = false;
			out.println("<script type=\"text/javascript\">");
			out.println("alert('Account is locked');");
			out.println("</script>");
		} catch (AuthenticationError e) {
			login = false;
			out.println("<script type=\"text/javascript\">");
			out.println("alert('Authentication error - try again');");
			out.println("</script>");
		}
	}

	private void showLogout(PrintWriter out) {
		out.println("<form action = '/SegSoftProj/test' method=\"post\" id=\"form6\">");
		out.println(
				"<button type=\"submit\" name=\"logoutButton\" form=\"form6\" value=\"Submit\">Logout</button><br><br>");
		out.println("</form>");
	}

	private void showmyAppButton(PrintWriter out) {
		out.println("<form action = '/SegSoftProj/test' method=\"post\" id=\"form7\">");
		out.println(
				"<button type=\"submit\" name=\"myAppButton\" form=\"form7\" value=\"Submit\">myApp Counter</button><br><br>");
		out.println("</form>");
	}

	private void logoutMethod(HttpServletRequest request, AuthenticatorInterface auth, PrintWriter out) {
		String button = request.getParameter("logoutButton");
		if (button != null) {
			HttpSession session = request.getSession(false);
			if (session != null && session.getAttribute("Name") != null) {
				auth.logout((String) session.getAttribute("Name"));
				session.invalidate();
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Account logged out');");
				out.println("</script>");
			} else {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('No account logged in');");
				out.println("</script>");
			}
		}
	}

	private void gotoMyAppMethod(HttpServletRequest req, HttpServletResponse resp, AuthenticatorInterface auth,
			PrintWriter out) {
		String button = req.getParameter("myAppButton");
		if (button != null) {
			HttpSession session = req.getSession(false);
			if (session == null) {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('No account logged in - Access Forbidden');");
				out.println("</script>");
			} else {
				try {
					resp.sendRedirect("/SegSoftProj/myApp");
				} catch (IOException e) {
					out.println("<script type=\"text/javascript\">");
					out.println("alert('Error redirecting');");
					out.println("</script>");
				}
			}
		}
	}
}
