package Account;

public interface AccountInterface {
	String getUsername();

	void setUsername(String username);

	String getPassword();

	void setPassword(String password);

	boolean isLogged_in();

	void setLogged_in(boolean logged_in);

	boolean isLocked();

	void setLocked(boolean locked);
}
