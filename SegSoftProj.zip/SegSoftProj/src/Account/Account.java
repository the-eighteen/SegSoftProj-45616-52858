package Account;

import java.io.Serializable;

public class Account implements AccountInterface, Serializable {

	private static final long serialVersionUID = 1L;
	private String username;
	private String password;
	private boolean logged_in;
	private boolean locked;

	public Account(String username, String password, boolean logged_in, boolean locked) {
		this.username = username;
		this.password = password;
		this.logged_in = logged_in;
		this.locked = locked;
	}

	public Account(String username, String password) {
		this.username = username;
		this.password = password;
		this.logged_in = false;
		this.locked = false;
	}

	@Override
	public String getUsername() {
		return username;
	}

	@Override
	public void setUsername(String username) {
		this.username = username;
	}

	@Override
	public String getPassword() {
		return password;
	}

	@Override
	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public boolean isLogged_in() {
		return logged_in;
	}

	@Override
	public void setLogged_in(boolean logged_in) {
		this.logged_in = logged_in;
	}

	@Override
	public boolean isLocked() {
		return locked;
	}

	@Override
	public void setLocked(boolean locked) {
		this.locked = locked;
	}

}
