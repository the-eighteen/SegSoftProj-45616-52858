import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class myAppServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static int counter = 0;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		out.println("<HTML>");
		out.println("<HEAD>");
		out.println("</HEAD>");
		out.println("<BODY>");
		out.println("<H1>The Counter App!</H1>");
		out.println("<H1>Value=" + counter + "</H1>");
		out.print("<form action= '/SegSoftProj/myApp'");
		out.println("method=GET>");
		out.println("<br>");
		out.println("<input type=submit name=increment>");
		out.println("</form>");
		showLeave(out);
		out.println("</BODY>");
		out.println("</HTML>");
		counter++;
		leaveMethod(request, response, out);
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	private void showLeave(PrintWriter out) {
		out.println("<form action = '/SegSoftProj/myApp' method=\"post\" id=\"form1\">");
		out.println(
				"<button type=\"submit\" name=\"myAppButton\" form=\"form1\" value=\"Submit\">Leave App</button><br><br>");
		out.println("</form>");
	}
	
	private void leaveMethod(HttpServletRequest request, HttpServletResponse response, PrintWriter out) {
		String button = request.getParameter("myAppButton");
		if(button != null) {
			try {
				response.sendRedirect("/SegSoftProj/test");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
