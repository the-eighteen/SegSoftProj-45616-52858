package Exceptions;

public class IncompleteParametersException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public IncompleteParametersException() {
		super("Please fill all parameters");
	}

}
