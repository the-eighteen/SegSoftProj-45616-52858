package Exceptions;

public class LockedException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public LockedException() {
        super("Account is Locked");
    }
}
