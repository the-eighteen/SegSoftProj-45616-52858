package Exceptions;

public class LoggedInException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public LoggedInException() {
        super("Account is Logged In");
    }
}
