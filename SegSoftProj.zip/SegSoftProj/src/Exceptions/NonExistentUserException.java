package Exceptions;

public class NonExistentUserException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NonExistentUserException() {
        super("User does not exist");
    }
}
