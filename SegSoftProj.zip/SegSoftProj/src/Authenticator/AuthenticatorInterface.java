package Authenticator;

import Account.AccountInterface;
import Exceptions.*;

import javax.servlet.http.*;

public interface AuthenticatorInterface {


    void create_account(String name, String pwd1, String pwd2) throws PasswordException, UserExistsException, IncompleteParametersException;
    void delete_account(String name) throws NonExistentUserException, LoggedInException, IncompleteParametersException;
    AccountInterface get_account(String name) throws NonExistentUserException;
    void change_pwd(String name, String pwd1, String pwd2) throws NonExistentUserException, PasswordException;
    AccountInterface login(String name, String pwd) throws NonExistentUserException, LockedException, AuthenticationError;
    void logout(String name);
    AccountInterface login(HttpServletRequest req, HttpServletResponse resp) throws NonExistentUserException, LockedException, AuthenticationError;

}
