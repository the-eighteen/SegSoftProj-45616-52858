package Authenticator;

import Account.*;
import Exceptions.*;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.Key;
import java.util.HashMap;

public class Authenticator implements AuthenticatorInterface {

	private static final String ALGO = "AES";
	Key key = new SecretKeySpec(keyValue, ALGO);
	private static final byte[] keyValue = new byte[] { 'F', 'C', 'T', '/', 'U', 'N', 'L', 'r', 'o', 'c', 'k', 's', '!',
			'!', 'd', 'i' };
	File file;
	HashMap<String, AccountInterface> accounts;

	public Authenticator() {
		file = new File(System.getProperty("user.home") + "\\Documents\\AccountDB.txt");
		try {
			file.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
		getFromFile();
	}

	@SuppressWarnings("unchecked")
	private void getFromFile() {
		FileInputStream fileIn = null;
		ObjectInputStream objIn = null;
		try {
			fileIn = new FileInputStream(file);
			if (fileIn.available() != 0)
				objIn = new ObjectInputStream(fileIn);
			else
				fileIn.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		if (objIn != null) {
			Object ob;
			try {
				ob = objIn.readObject();
				accounts = (HashMap<String, AccountInterface>) ob;
				objIn.close();
				fileIn.close();
			} catch (ClassNotFoundException | IOException e) {
				e.printStackTrace();
			}
		} else {
			accounts = new HashMap<>();
			String encPass = null;
			try {
				encPass = encrypt("root");
			} catch (Exception e) {
				e.printStackTrace();
			}
			accounts.put("root", new Account("root", encPass));
			updateFile();
		}
	}

	private void updateFile() {
		try {
			FileOutputStream fileIn = new FileOutputStream(file);
			ObjectOutputStream out = new ObjectOutputStream(fileIn);
			out.writeObject(accounts);
			out.close();
			fileIn.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void create_account(String name, String pwd1, String pwd2)
			throws PasswordException, UserExistsException, IncompleteParametersException {
		if (name == null || pwd1 == null || pwd2 == null) {
			throw new IncompleteParametersException();
		}
		if (!pwd1.equals(pwd2))
			throw new PasswordException();
		if (accounts.containsKey(name))
			throw new UserExistsException();
		String encPass = null;
		try {
			encPass = encrypt(pwd1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AccountInterface acc = new Account(name, encPass);
		accounts.put(name, acc);
		updateFile();
	}

	@Override
	public void delete_account(String name)
			throws NonExistentUserException, LoggedInException, IncompleteParametersException {
		if (name == null) {
			throw new IncompleteParametersException();
		}
		if (!accounts.containsKey(name))
			throw new NonExistentUserException();
		AccountInterface acc = accounts.get(name);
		if (acc.isLogged_in())
			throw new LoggedInException();
		if (!acc.isLocked()) {
			acc.setLocked(true);
			accounts.replace(name, acc);
			updateFile();
		}
		accounts.remove(name);
		updateFile();
	}

	@Override
	public AccountInterface get_account(String name) throws NonExistentUserException {
		AccountInterface acc = accounts.get(name);
		if (acc == null)
			throw new NonExistentUserException();
		return acc;
	}

	@Override
	public void change_pwd(String name, String pwd1, String pwd2) throws NonExistentUserException, PasswordException {
		if (!accounts.containsKey(name))
			throw new NonExistentUserException();
		if (pwd1.equals(pwd2))
			throw new PasswordException();
		String encPwd = null;
		try {
			encPwd = encrypt(pwd1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		AccountInterface acc = accounts.get(name);
		acc.setPassword(encPwd);
		accounts.replace(name, acc);
		updateFile();
	}

	@Override
	public AccountInterface login(String name, String pwd)
			throws NonExistentUserException, LockedException, AuthenticationError {
		AccountInterface acc = accounts.get(name);
		if (acc == null)
			throw new NonExistentUserException();
		if (acc.isLocked())
			throw new LockedException();
		String encPwd = null;
		try {
			encPwd = encrypt(pwd);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (!acc.getPassword().equals(encPwd))
			throw new AuthenticationError();
		acc.setLogged_in(true);
		accounts.replace(name, acc);
		updateFile();
		return acc;
	}

	@Override
	public void logout(String name) {
		AccountInterface acc = accounts.get(name);
		if (acc.isLogged_in()) {
			acc.setLogged_in(false);
			accounts.replace(name, acc);
			updateFile();
		}
	}

	@Override
	public AccountInterface login(HttpServletRequest req, HttpServletResponse resp)
			throws NonExistentUserException, LockedException, AuthenticationError {
		String username = req.getParameter("usernameLogin");
		String password = req.getParameter("pwdLogin");
		if (username != null && password != null) {
			AccountInterface acc = login(username, password);
			HttpSession session = req.getSession();
			session.setAttribute("Name", username);
			session.setAttribute("Pwd", acc.getPassword());
			return acc;
		}
		return null;
	}

	public String encrypt(String Data) throws Exception {
		Cipher c = Cipher.getInstance(ALGO);
		c.init(Cipher.ENCRYPT_MODE, key);
		byte[] encVal = c.doFinal(Data.getBytes());
		return java.util.Base64.getEncoder().encodeToString(encVal);
	}

	public String decrypt(String encrypted) throws Exception {
		Cipher c = Cipher.getInstance(ALGO);
		c.init(Cipher.DECRYPT_MODE, key);
		byte[] decodedValue = java.util.Base64.getDecoder().decode(encrypted);
		byte[] decValue = c.doFinal(decodedValue);
		return new String(decValue);
	}

}
